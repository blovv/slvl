from typing import TYPE_CHECKING

from .enums import *

if TYPE_CHECKING:
    from .types import *


def file(data: dict) -> "FileObject":
    from .types import FileObject
    if not data:
        return None

    return FileObject(
        id=data.get("id"),
        url=data.get("url"),
        filename=data.get("filename"),
        mime=data.get("mime"),
    )


def sbp_bank_member(data: dict) -> "SBPBankMember":
    from .types import SBPBankMember
    if not data:
        return None

    return SBPBankMember(
        id=data.get("id"),
        name=data.get("name"),
        icon=data.get("icon")
    )


def transaction_payment_method(data: dict) -> "TransactionPaymentMethod":
    from .types import TransactionPaymentMethod
    from .parser import transaction_provider_props, transaction_provider_limits
    if not data:
        return None

    return TransactionPaymentMethod(
        id=TransactionPaymentMethodIds.__members__.get(data.get("id")),
        name=data.get("name"),
        fee=data.get("fee"),
        provider_id=TransactionProviderIds.__members__.get(data.get("provider_id")),
        account=account_profile(data.get("account")),
        props=transaction_provider_props(data.get("props")),
        limits=transaction_provider_limits(data.get("limits"))
    )


def transaction_provider_limit_range(data: dict) -> "TransactionProviderLimitRange":
    from .types import TransactionProviderLimitRange
    if not data:
        return None

    return TransactionProviderLimitRange(
        min=data.get("min"),
        max=data.get("max")
    )


def transaction_provider_limits(data: dict) -> "TransactionProviderLimits":
    from .types import TransactionProviderLimits
    if not data:
        return None

    return TransactionProviderLimits(
        incoming=transaction_provider_limit_range(data.get("incoming")),
        outgoing=transaction_provider_limit_range(data.get("outgoing"))
    )


def transaction_provider_required_user_data(data: dict) -> "TransactionProviderRequiredUserData":
    from .types import TransactionProviderRequiredUserData
    if not data:
        return None

    return TransactionProviderRequiredUserData(
        email=data.get("email"),
        phone_number=data.get("phoneNumber"),
        erip_account_number=data.get("eripAccountNumber")
    )


def transaction_provider_props(data: dict) -> "TransactionProviderProps":
    from .types import TransactionProviderProps
    if not data:
        return None

    return TransactionProviderProps(
        required_user_data=transaction_provider_required_user_data(data.get("requiredUserData")),
        tooltip=data.get("tooltip")
    )


def transaction_provider(data: dict) -> "TransactionProvider":
    from .types import TransactionProvider
    from .parser import account_profile
    if not data:
        return None

    return TransactionProvider(
        id=TransactionProviderIds.__members__.get(data.get("id")),
        name=data.get("name"),
        fee=data.get("fee"),
        min_fee_amount=data.get("minFeeAmount"),
        description=data.get("description"),
        account=account_profile(data.get("account")),
        props=transaction_provider_props(data.get("props")),
        limits=transaction_provider_limits(data.get("limits")),
        payment_methods=[transaction_payment_method(method) for method in (data.get("paymentMethods") or [])]
    )


def transaction_props_user_data(data: dict) -> "TransactionPropsUserData":
    from .types import TransactionPropsUserData
    if not data:
        return None

    return TransactionPropsUserData(
        account=data.get("account"),
        email=data.get("email"),
        ip_address=data.get("ipAddress"),
        phone_number=data.get("phoneNumber"),
    )


def transaction_props_payment_account(data: dict) -> "TransactionPropsPaymentAccount":
    from .types import TransactionPropsPaymentAccount
    if not data:
        return None

    return TransactionPropsPaymentAccount(
        id=data.get("id"),
        value=data.get("value"),
    )


def transaction_props(data: dict) -> "TransactionProps":
    from .types import TransactionProps
    if not data:
        return None

    return TransactionProps(
        creator_id=data.get("creatorId"),
        deal_id=data.get("dealId"),
        paid_from_pending_income=data.get("paidFromPendingIncome"),
        payment_url=data.get("paymentURL"),
        success_url=data.get("successURL"),
        fee=data.get("fee"),
        payment_account=transaction_props_payment_account(data.get("paymentAccount")),
        payment_gateway=data.get("paymentGateway"),
        already_spent=data.get("alreadySpent"),
        exchange_rate=data.get("exchangeRate"),
        amount_after_conversion_rub=data.get("amountAfterConversionRub"),
        amount_after_conversion_usdt=data.get("amountAfterConversionUsdt"),
        fragment_username=data.get("fragmentUsername"),
        user_data=transaction_props_user_data(data.get("userData")),
    )


def transaction(data: dict) -> "Transaction":
    from .types import Transaction
    if not data:
        return None

    return Transaction(
        id=data.get("id"),
        operation=TransactionOperations.__members__.get(data.get("operation")),
        direction=TransactionDirections.__members__.get(data.get("direction")),
        provider_id=TransactionProviderIds.__members__.get(data.get("providerId")),
        provider=transaction_provider(data.get("provider")),
        user=user_profile(data.get("user")),
        creator=user_profile(data.get("creator")),
        status=TransactionStatuses.__members__.get(data.get("status")),
        status_description=data.get("statusDescription"),
        status_expiration_date=data.get("statusExpirationDate"),
        value=data.get("value"),
        fee=data.get("fee"),
        created_at=data.get("createdAt"),
        verified_at=data.get("verifiedAt"),
        verified_by=user_profile(data.get("verifiedBy")),
        completed_at=data.get("completedAt"),
        completed_by=user_profile(data.get("completedBy")),
        payment_method_id=data.get("paymentMethodId"),
        is_suspicious=data.get("isSuspicious"),
        sbp_bank_name=data.get("spbBankName"),
        props=transaction_props(data.get("props")),
    )


def transaction_page_info(data: dict) -> "TransactionPageInfo":
    from .types import TransactionPageInfo
    if not data:
        return None

    return TransactionPageInfo(
        start_cursor=data.get("startCursor"),
        end_cursor=data.get("endCursor"),
        has_previous_page=data.get("hasPreviousPage"),
        has_next_page=data.get("hasNextPage")
    )


def transaction_list(data: dict) -> "TransactionList":
    from .types import TransactionList
    if not data:
        return None

    return TransactionList(
        transactions=[transaction(edge.get("node")) for edge in (data.get("edges") or [])],
        page_info=transaction_page_info(data.get("pageInfo")),
        total_count=data.get("totalCount")
    )


def user_bank_card(data: dict) -> "UserBankCard":
    from .types import UserBankCard
    if not data:
        return None

    return UserBankCard(
        id=data.get("id"),
        card_first_six=data.get("cardFirstSix"),
        card_last_four=data.get("cardLastFour"),
        card_type=BankCardTypes.__members__.get(data.get("cardType")),
        is_chosen=data.get("isChosen")
    )


def user_bank_card_page_info(data: dict) -> "UserBankCardPageInfo":
    from .types import UserBankCardPageInfo
    if not data:
        return None

    return UserBankCardPageInfo(
        start_cursor=data.get("startCursor"),
        end_cursor=data.get("endCursor"),
        has_previous_page=data.get("hasPreviousPage"),
        has_next_page=data.get("hasNextPage")
    )


def user_bank_card_list(data: dict) -> "UserBankCardList":
    from .types import UserBankCardList
    if not data:
        return None

    return UserBankCardList(
        bank_cards=[user_bank_card(edge.get("node")) for edge in (data.get("edges") or [])],
        page_info=user_bank_card_page_info(data.get("pageInfo")),
        total_count=data.get("totalCount")
    )


def game_category_data_field(data: dict) -> "GameCategoryDataField":
    from .types import GameCategoryDataField
    if not data:
        return None

    return GameCategoryDataField(
        id=data.get("id"),
        label=data.get("label"),
        type=GameCategoryDataFieldTypes.__members__.get(data.get("type")),
        input_type=GameCategoryDataFieldInputTypes.__members__.get(data.get("inputType")),
        copyable=data.get("copyable"),
        hidden=data.get("hidden"),
        required=data.get("required"),
        value=data.get("value"),
    )


def game_category_data_field_page_info(data: dict) -> "GameCategoryDataFieldPageInfo":
    from .types import GameCategoryDataFieldPageInfo
    if not data:
        return None

    return GameCategoryDataFieldPageInfo(
        start_cursor=data.get("startCursor"),
        end_cursor=data.get("endCursor"),
        has_previous_page=data.get("hasPreviousPage"),
        has_next_page=data.get("hasNextPage"),
    )


def game_category_data_field_list(data: dict) -> "GameCategoryDataFieldList":
    from .types import GameCategoryDataFieldList
    if not data:
        return None
    
    return GameCategoryDataFieldList(
        data_fields=[game_category_data_field(edge.get("node")) for edge in (data.get("edges") or [])],
        page_info=game_category_data_field_page_info(data.get("pageInfo")),
        total_count=data.get("totalCount"),
    )


def game_category_props(data: dict) -> "GameCategoryProps":
    from .types import GameCategoryProps
    if not data:
        return None

    return GameCategoryProps(
        min_reviews=data.get("minTestimonials"),
        min_reviews_for_seller=data.get("minTestimonialsForSeller"),
    )


def game_category_option_value_range_limit(data: dict) -> "GameCategoryOptionValueRangeLimit":
    from .types import GameCategoryOptionValueRangeLimit
    if not data:
        return None

    return GameCategoryOptionValueRangeLimit(
        min=data.get("min"),
        max=data.get("max"),
    )


def game_category_option(data: dict) -> "GameCategoryOption":
    from .types import GameCategoryOption
    if not data:
        return None

    return GameCategoryOption(
        id=data.get("id"),
        group=data.get("group"),
        label=data.get("label"),
        type=GameCategoryOptionTypes.__members__.get(data.get("type")),
        field=data.get("field"),
        value=data.get("value"),
        value_range_limit=game_category_option_value_range_limit(data.get("valueRangeLimit")),
        multiple=data.get("multiple"),
    )


def game_category_agreement(data: dict) -> "GameCategoryAgreement":
    from .types import GameCategoryAgreement
    if not data:
        return None

    return GameCategoryAgreement(
        id=data.get("id"),
        description=data.get("description"),
        icontype=GameCategoryAgreementIconTypes.__members__.get(data.get("iconType")),
        sequence=data.get("sequence"),
        game_category_id=data.get("gameCategoryId"),
        game_category_obtaining_type_id=data.get("gameCategoryObtainingTypeId"),
    )


def game_category_agreement_page_info(data: dict) -> "GameCategoryAgreementPageInfo":
    from .types import GameCategoryAgreementPageInfo
    if not data:
        return None

    return GameCategoryAgreementPageInfo(
        start_cursor=data.get("startCursor"),
        end_cursor=data.get("endCursor"),
        has_previous_page=data.get("hasPreviousPage"),
        has_next_page=data.get("hasNextPage"),
    )


def game_category_agreement_list(data: dict) -> "GameCategoryAgreementList":
    from .types import GameCategoryAgreementList
    if not data:
        return None
    
    return GameCategoryAgreementList(
        agreements=[game_category_agreement(edge.get("node")) for edge in (data.get("edges") or [])],
        page_info=game_category_agreement_page_info(data.get("pageInfo")),
        total_count=data.get("totalCount"),
    )


def game_category_obtaining_type(data: dict) -> "GameCategoryObtainingType":
    from .types import GameCategoryObtainingType
    if not data:
        return None
    
    return GameCategoryObtainingType(
        id=data.get("id"),
        name=data.get("name"),
        description=data.get("description"),
        game_category_id=data.get("gameCategoryId"),
        no_comment_from_buyer=data.get("noCommentFromBuyer"),
        instruction_for_buyer=data.get("instructionForBuyer"),
        instruction_for_seller=data.get("instructionForSeller"),
        sequence=data.get("sequence"),
        fee_multiplier=data.get("feeMultiplier"),
        agreements=[game_category_agreement(agr) for agr in (data.get("agreements") or [])],
        props=game_category_props(data.get("props")),
        stock_type=data.get("stockType"),
    )


def game_category_obtaining_type_page_info(data: dict) -> "GameCategoryObtainingTypePageInfo":
    from .types import GameCategoryObtainingTypePageInfo
    if not data:
        return None

    return GameCategoryObtainingTypePageInfo(
        start_cursor=data.get("startCursor"),
        end_cursor=data.get("endCursor"),
        has_previous_page=data.get("hasPreviousPage"),
        has_next_page=data.get("hasNextPage"),
    )


def game_category_obtaining_type_list(data: dict) -> "GameCategoryObtainingTypeList":
    from .types import GameCategoryObtainingTypeList
    if not data:
        return None
    
    return GameCategoryObtainingTypeList(
        obtaining_types=[game_category_obtaining_type(edge.get("node")) for edge in (data.get("edges") or [])],
        page_info=game_category_obtaining_type_page_info(data.get("pageInfo")),
        total_count=data.get("totalCount"),
    )


def game_category_instruction(data: dict) -> "GameCategoryInstruction":
    from .types import GameCategoryInstruction
    if not data:
        return None

    return GameCategoryInstruction(
        id=data.get("id"), 
        text=data.get("text")
    )


def game_category_instruction_page_info(data: dict) -> "GameCategoryInstructionPageInfo":
    from .types import GameCategoryInstructionPageInfo
    if not data:
        return None

    return GameCategoryInstructionPageInfo(
        start_cursor=data.get("startCursor"),
        end_cursor=data.get("endCursor"),
        has_previous_page=data.get("hasPreviousPage"),
        has_next_page=data.get("hasNextPage"),
    )


def game_category_instruction_list(data: dict) -> "GameCategoryInstructionList":
    from .types import GameCategoryInstructionList
    if not data:
        return None
    
    return GameCategoryInstructionList(
        instructions=[game_category_instruction(edge.get("node")) for edge in (data.get("edges") or [])],
        page_info=game_category_instruction_page_info(data.get("pageInfo")),
        total_count=data.get("totalCount"),
    )


def game_category(data: dict) -> "GameCategory":
    from .types import GameCategory
    if not data:
        return None
    
    return GameCategory(
        id=data.get("id"),
        slug=data.get("slug"),
        name=data.get("name"),
        category_id=data.get("categoryId"),
        game_id=data.get("gameId"),
        obtaining=data.get("obtaining"),
        options=[game_category_option(option) for option in (data.get("options") or [])],
        props=game_category_props(data.get("props")),
        no_comment_from_buyer=data.get("noCommentFromBuyer"),
        instruction_for_buyer=data.get("instructionForBuyer"),
        instruction_for_seller=data.get("instructionForSeller"),
        use_custom_obtaining=data.get("useCustomObtaining"),
        auto_confirm_period=GameCategoryAutoConfirmPeriods.__members__.get(data.get("autoConfirmPeriod")),
        auto_moderation_mode=data.get("autoModerationMode"),
        agreements=[game_category_agreement(agr) for agr in (data.get("agreements") or [])],
        fee_multiplier=data.get("feeMultiplier"),
    )


def game(data: dict) -> "Game":
    from .types import Game
    if not data:
        return None
    
    return Game(
        id=data.get("id"),
        slug=data.get("slug"),
        name=data.get("name"),
        type=GameTypes.__members__.get(data.get("type")),
        logo=file(data.get("logo")),
        banner=file(data.get("banner")),
        categories=[game_category(cat) for cat in (data.get("categories") or [])],
        created_at=data.get("createdAt"),
    )


def game_profile(data: dict) -> "GameProfile":
    from .types import GameProfile
    if not data:
        return None

    return GameProfile(
        id=data.get("id"),
        slug=data.get("slug"),
        name=data.get("name"),
        type=GameTypes.__members__.get(data.get("type")),
        logo=file(data.get("logo")),
    )


def game_page_info(data: dict) -> "GamePageInfo":
    from .types import GamePageInfo
    if not data:
        return None

    return GamePageInfo(
        start_cursor=data.get("startCursor"),
        end_cursor=data.get("endCursor"),
        has_previous_page=data.get("hasPreviousPage"),
        has_next_page=data.get("hasNextPage"),
    )


def game_list(data: dict) -> "GameList":
    from .types import GameList
    if not data:
        return None
    
    return GameList(
        games=[game(edge.get("node")) for edge in (data.get("edges") or [])],
        page_info=game_page_info(data.get("pageInfo")),
        total_count=data.get("totalCount"),
    )


def user_profile(data: dict) -> "UserProfile":
    from .types import UserProfile
    if not data:
        return None
    
    return UserProfile(
        id=data.get("id"),
        username=data.get("username", "Поддержка"),
        role=UserTypes.__members__.get(data.get("role")),
        avatar_url=data.get("avatarURL"),
        is_online=data.get("isOnline"),
        is_blocked=data.get("isBlocked"),
        rating=data.get("rating"),
        reviews_count=data.get("testimonialCounter"),
        created_at=data.get("createdAt"),
        support_chat_id=data.get("supportChatId"),
        system_chat_id=data.get("systemChatId"),
    )


def account_items_stats(data: dict) -> "AccountItemsStats":
    from .types import AccountItemsStats
    if not data:
        return None

    return AccountItemsStats(
        total=data.get("total"), 
        finished=data.get("finished")
    )


def account_incoming_deals_stats(data: dict) -> "AccountIncomingDealsStats":
    from .types import AccountIncomingDealsStats
    if not data:
        return None

    return AccountIncomingDealsStats(
        total=data.get("total"), 
        finished=data.get("finished")
    )


def account_outgoing_deals_stats(data: dict) -> "AccountOutgoingDealsStats":
    from .types import AccountOutgoingDealsStats
    if not data:
        return None

    return AccountOutgoingDealsStats(
        total=data.get("total"), 
        finished=data.get("finished")
    )


def account_deals_stats(data: dict) -> "AccountDealsStats":
    from .types import AccountDealsStats
    if not data:
        return None

    return AccountDealsStats(
        incoming=account_incoming_deals_stats(data.get("incoming")),
        outgoing=account_outgoing_deals_stats(data.get("outgoing")),
    )


def account_stats(data: dict) -> "AccountStats":
    from .types import AccountStats
    if not data:
        return None
    
    return AccountStats(
        items=account_items_stats(data.get("items")), 
        deals=account_deals_stats(data.get("deals"))
    )


def account_balance(data: dict) -> "AccountBalance":
    from .types import AccountBalance
    if not data:
        return None

    return AccountBalance(
        id=data.get("id"),
        value=data.get("value"),
        frozen=data.get("frozen"),
        available=data.get("available"),
        withdrawable=data.get("withdrawable"),
        pending_income=data.get("pendingIncome"),
    )


def account_profile(data: dict) -> "AccountProfile":
    from .types import AccountProfile
    if not data:
        return None
    
    profile: dict = data.get("profile", {})
    return AccountProfile(
        id=data.get("id"),
        username=profile.get("username"),
        email=data.get("email"),
        balance=account_balance(data.get("balance")),
        stats=account_stats(data.get("stats")),
        role=UserTypes.__members__.get(data.get("role")),
        avatar_url=profile.get("avatarURL"),
        is_online=profile.get("isOnline"),
        is_blocked=data.get("isBlocked"),
        is_blocked_for=data.get("isBlockedFor"),
        is_verified=data.get("isVerified"),
        rating=profile.get("rating"),
        reviews_count=profile.get("testimonialCounter"),
        created_at=profile.get("createdAt"),
        support_chat_id=profile.get("supportChatId"),
        system_chat_id=profile.get("systemChatId"),
        has_frozen_balance=data.get("hasFrozenBalance"),
        has_enabled_notifications=data.get("hasEnabledNotifications"),
        unread_chats_counter=data.get("unreadChatsCounter")
    )


def item_priority_status_price_range(data: dict) -> "ItemPriorityStatusPriceRange":
    from .types import ItemPriorityStatusPriceRange
    if not data:
        return None

    return ItemPriorityStatusPriceRange(
        min=data.get("min"), 
        max=data.get("max")
    )


def item_priority_status(data: dict) -> "ItemPriorityStatus":
    from .types import ItemPriorityStatus
    if not data:
        return None

    return ItemPriorityStatus(
        id=data.get("id"),
        price=data.get("price"),
        name=data.get("name"),
        type=PriorityTypes.__members__.get(data.get("type")),
        period=data.get("period"),
        price_range=item_priority_status_price_range(data.get("priceRange")),
    )


def item_log(data: dict) -> "ItemLog":
    from .types import ItemLog
    if not data:
        return None

    return ItemLog(
        id=data.get("id"),
        event=ItemLogEvents.__members__.get(data.get("event")),
        created_at=data.get("createdAt"),
        user=user_profile(data.get("user")),
    )


def item_characteristic(data: dict) -> "ItemCharacteristic":
    from .types import ItemCharacteristic
    if not data:
        return None

    return ItemCharacteristic(
        label=data.get("label"),
        value=data.get("value"),
    )


def item(data: dict) -> "Item":
    from .types import Item
    if not data:
        return None

    return Item(
        id=data.get("id"),
        slug=data.get("slug"),
        name=data.get("name"),
        description=data.get("description"),
        obtaining_type=game_category_obtaining_type(data.get("obtainingType")),
        price=data.get("price"),
        raw_price=data.get("rawPrice"),
        priority=PriorityTypes.__members__.get(data.get("priority")),
        priority_position=data.get("priorityPosition"),
        attachments=[file(att) for att in (data.get("attachments") or [])],
        attributes=data.get("attributes"),
        category=game_category(data.get("category")),
        comment=data.get("comment"),
        data_fields=[game_category_data_field(field) for field in (data.get("dataFields") or [])],
        fee_multiplier=data.get("feeMultiplier"),
        game=game_profile(data.get("game")),
        seller_type=UserTypes.__members__.get(data.get("sellerType")),
        status=ItemStatuses.__members__.get(data.get("status")),
        user=user_profile(data.get("user")),
        characteristics=[item_characteristic(char) for char in (data.get("characteristics") or [])],
        is_attachments_forbidden=data.get("isAttachmentsForbidden"),
        is_automated=data.get("isAutomated"),
        buyer=user_profile(data.get("buyer")),
        post_moderation_checked_at=data.get("postModerationCheckedAt"),
    )


def my_item(data: dict) -> "MyItem":
    from .types import MyItem
    if not data:
        return None

    return MyItem(
        id=data.get("id"),
        slug=data.get("slug"),
        name=data.get("name"),
        description=data.get("description"),
        obtaining_type=game_category_obtaining_type(data.get("obtainingType")),
        price=data.get("price"),
        prev_price=data.get("prevPrice"),
        raw_price=data.get("rawPrice"),
        priority_position=data.get("priorityPosition"),
        attachments=[file(att) for att in (data.get("attachments") or [])],
        attributes=data.get("attributes"),
        buyer=user_profile(data.get("buyer")),
        category=game_category(data.get("category")),
        comment=data.get("comment"),
        data_fields=[game_category_data_field(field) for field in (data.get("dataFields") or [])],
        fee_multiplier=data.get("feeMultiplier"),
        prev_fee_multiplier=data.get("prevFeeMultiplier"),
        seller_notified_about_fee_change=data.get("sellerNotifiedAboutFeeChange"),
        game=game_profile(data.get("game")),
        seller_type=UserTypes.__members__.get(data.get("sellerType")),
        status=ItemStatuses.__members__.get(data.get("status")),
        user=user_profile(data.get("user")),
        priority=PriorityTypes.__members__.get(data.get("priority")),
        priority_price=data.get("priorityPrice"),
        sequence=data.get("sequence"),
        status_expiration_date=data.get("statusExpirationDate"),
        status_description=data.get("statusDescription"),
        status_payment=transaction(data.get("statusPayment")),
        views_counter=data.get("viewsCounter"),
        is_editable=data.get("editable"),
        approval_date=data.get("approvalDate"),
        deleted_at=data.get("deletedAt"),
        updated_at=data.get("updatedAt"),
        created_at=data.get("createdAt"),
        characteristics=[item_characteristic(char) for char in (data.get("characteristics") or [])],
        is_attachments_forbidden=data.get("isAttachmentsForbidden"),
        is_automated=data.get("isAutomated"),
        deals_counter=data.get("dealsCounter"),
        keep_in_sale=data.get("keepInSale"),
        keep_in_sale_available=data.get("keepInSaleAvailable"),
        may_be_published=data.get("mayBePublished"),
        post_moderation_checked_at=data.get("postModerationCheckedAt"),
        moderator=moderator(data.get("moderator")),
    )


def item_profile(data: dict) -> "ItemProfile":
    from .types import ItemProfile
    if not data:
        return None

    return ItemProfile(
        id=data.get("id"),
        slug=data.get("slug"),
        priority=PriorityTypes.__members__.get(data.get("priority")),
        status=ItemStatuses.__members__.get(data.get("status")),
        name=data.get("name"),
        price=data.get("price"),
        raw_price=data.get("rawPrice"),
        seller_type=UserTypes.__members__.get(data.get("sellerType")),
        attachment=file(data.get("attachment")),
        user=user_profile(data.get("user")),
        approval_date=data.get("approvalDate"),
        priority_position=data.get("priorityPosition"),
        views_counter=data.get("viewsCounter"),
        fee_multiplier=data.get("feeMultiplier"),
        created_at=data.get("createdAt"),
        deals_counter=data.get("dealsCounter"),
        is_attachments_forbidden=data.get("isAttachmentsForbidden"),
        is_automated=data.get("isAutomated"),
    )


def item_by_typename(data: dict) -> "MyItem | Item | ItemProfile":
    if not data:
        return None

    type_name = data.get("__typename")
    if type_name == "MyItem":
        return my_item(data)
    elif type_name in ["MyItemProfile", "ForeignItemProfile", "ItemProfile"]:
        return item_profile(data)
    elif type_name in ["Item", "ForeignItem"]:
        return item(data)
    else:
        return None


def item_profile_page_info(data: dict) -> "ItemProfilePageInfo":
    from .types import ItemProfilePageInfo
    if not data:
        return None

    return ItemProfilePageInfo(
        start_cursor=data.get("startCursor"),
        end_cursor=data.get("endCursor"),
        has_previous_page=data.get("hasPreviousPage"),
        has_next_page=data.get("hasNextPage"),
    )


def item_profile_list(data: dict) -> "ItemProfileList":
    from .types import ItemProfileList
    if not data:
        return None
    
    return ItemProfileList(
        items=[item_profile(edge.get("node")) for edge in (data.get("edges") or [])],
        page_info=item_profile_page_info(data.get("pageInfo")),
        total_count=data.get("totalCount"),
    )


def moderator(data: dict) -> "Moderator":
    from .types import Moderator
    if not data:
        return None

    return Moderator(
        id=data.get("id"),
        username=data.get("username"),
    )


def event(data: dict): # TODO: Сделать парсинг класса Event
    ...  


def chat(data: dict) -> "Chat":
    from .types import Chat
    if not data:
        return None

    return Chat(
        id=data.get("id"),
        type=ChatTypes.__members__.get(data.get("type")),
        status=ChatStatuses.__members__.get(data.get("status")),
        unread_messages_counter=data.get("unreadMessagesCounter"),
        bookmarked=data.get("bookmarked"),
        is_texting_allowed=data.get("isTextingAllowed"),
        owner=user_profile(data.get("owner")),
        deals=[item_deal(deal) for deal in (data.get("deals") or [])],
        started_at=data.get("startedAt"),
        finished_at=data.get("finishedAt"),
        last_message=chat_message(data.get("lastMessage")),
        users=[user_profile(user) for user in (data.get("participants") or [])],
    )


def chat_page_info(data: dict) -> "ChatPageInfo":
    from .types import ChatPageInfo
    if not data:
        return None

    return ChatPageInfo(
        start_cursor=data.get("startCursor"),
        end_cursor=data.get("endCursor"),
        has_previous_page=data.get("hasPreviousPage"),
        has_next_page=data.get("hasNextPage"),
    )


def chat_list(data: dict) -> "ChatList":
    from .types import ChatList
    if not data:
        return None
    
    return ChatList(
        chats=[chat(edge.get("node")) for edge in (data.get("edges") or [])],
        page_info=chat_page_info(data.get("pageInfo")),
        total_count=data.get("totalCount"),
    )


def review(data: dict) -> "Review":
    from .types import Review
    if not data:
        return None

    return Review(
        id=data.get("id"),
        status=ReviewStatuses.__members__.get(data.get("status")),
        text=data.get("text"),
        rating=data.get("rating"),
        created_at=data.get("createdAt"),
        updated_at=data.get("updatedAt"),
        deal=item_deal(data.get("deal")),
        creator=user_profile(data.get("creator")),
        moderator=moderator(data.get("moderator")),
        user=user_profile(data.get("user")),
    )


def review_page_info(data: dict) -> "ReviewPageInfo":
    from .types import ReviewPageInfo
    if not data:
        return None

    return ReviewPageInfo(
        start_cursor=data.get("startCursor"),
        end_cursor=data.get("endCursor"),
        has_previous_page=data.get("hasPreviousPage"),
        has_next_page=data.get("hasNextPage"),
    )


def review_list(data: dict) -> "ReviewList":
    from .types import ReviewList
    if not data:
        return None
    
    return ReviewList(
        reviews=[review(edge.get("node")) for edge in (data.get("edges") or [])],
        page_info=review_page_info(data.get("pageInfo")),
        total_count=data.get("totalCount"),
    )


def item_deal_confirmation_restriction_texts(data: dict) -> "ItemDealConfirmationRestrictionTexts":
    from .types import ItemDealConfirmationRestrictionTexts
    if not data:
        return None

    return ItemDealConfirmationRestrictionTexts(
        seller_deal_subtitle=data.get("sellerDealSubtitle"),
        buyer_deal_subtitle=data.get("buyerDealSubtitle"),
        buyer_timer_text=data.get("buyerTimerText"),
    )


def item_deal_props(data: dict) -> "ItemDealProps":
    from .types import ItemDealProps
    if not data:
        return None

    return ItemDealProps(
        auto_confirm_period=data.get("autoConfirmPeriod"),
        confirmation_restriction=data.get("confirmationRestriction"),
        confirmation_restriction_texts=item_deal_confirmation_restriction_texts(data.get("confirmationRestrictionTexts")),
    )


def item_deal_warning(data: dict) -> "ItemDealWarning":
    from .types import ItemDealWarning
    if not data:
        return None

    return ItemDealWarning(
        id=data.get("id"),
        status=ItemDealStatuses.__members__.get(data.get("status")),
        title=data.get("title"),
        text=data.get("text"),
    )


def item_deal_automation_obtaining_field(data: dict) -> "ItemDealAutomationObtainingField":
    from .types import ItemDealAutomationObtainingField
    if not data:
        return None

    return ItemDealAutomationObtainingField(
        code=data.get("code"),
        value=data.get("value"),
        name=data.get("name"),
    )


def item_deal(data: dict) -> "ItemDeal":
    from .types import ItemDeal
    if not data:
        return None
    
    return ItemDeal(
        id=data.get("id"),
        status=ItemDealStatuses.__members__.get(data.get("status")),
        status_expiration_date=data.get("statusExpirationDate"),
        status_description=data.get("statusDescription"),
        direction=ItemDealDirections.__members__.get(data.get("direction")),
        obtaining=data.get("obtaining"),
        has_problem=data.get("hasProblem"),
        report_problem_enabled=data.get("reportProblemEnabled"),
        completed_user=user_profile(data.get("completedBy")),
        props=item_deal_props(data.get("props")),
        previous_status=ItemDealStatuses.__members__.get(data.get("prevStatus")),
        completed_at=data.get("completedAt"),
        created_at=data.get("createdAt"),
        logs=[item_log(log) for log in (data.get("logs") or [])],
        transaction=transaction(data.get("transaction")),
        user=user_profile(data.get("user")),
        chat=chat(data.get("chat")),
        item=item_by_typename(data.get("item")),
        review=review(data.get("testimonial")),
        obtaining_fields=[game_category_data_field(field) for field in (data.get("obtainingFields") or [])],
        comment_from_buyer=data.get("commentFromBuyer"),
        automation_obtaining_fields=[item_deal_automation_obtaining_field(field) for field in (data.get("automationObtainingFields") or [])],
        game_category_warnings=[item_deal_warning(warning) for warning in (data.get("gameCategoryWarnings") or [])],
        obtaining_type_warnings=[item_deal_warning(warning) for warning in (data.get("obtainingTypeWarnings") or [])],
        is_automated=data.get("isAutomated"),
    )


def item_deal_page_info(data: dict) -> "ItemDealPageInfo":
    from .types import ItemDealPageInfo
    if not data:
        return None

    return ItemDealPageInfo(
        start_cursor=data.get("startCursor"),
        end_cursor=data.get("endCursor"),
        has_previous_page=data.get("hasPreviousPage"),
        has_next_page=data.get("hasNextPage"),
    )


def item_deal_list(data: dict) -> "ItemDealList":
    from .types import ItemDealList
    if not data:
        return None
    
    return ItemDealList(
        deals=[item_deal(edge.get("node")) for edge in (data.get("edges") or [])],
        page_info=item_deal_page_info(data.get("pageInfo")),
        total_count=data.get("totalCount"),
    )


def temporary_attachment_upload_output(data: dict) -> "TemporaryAttachmentUploadOutput":
    from .types import TemporaryAttachmentUploadOutput
    if not data:
        return None

    return TemporaryAttachmentUploadOutput(
        id=data.get("id"),
        url=data.get("url"),
        chat_id=data.get("chatId"),
        client_attachment_id=data.get("clientAttachmentId"),
        expires_at=data.get("expiresAt")
    )


def chat_message_button(data: dict) -> "ChatMessageButton":
    from .types import ChatMessageButton
    if not data:
        return None

    return ChatMessageButton(
        type=ChatMessageButtonTypes.__members__.get(data.get("type")),
        url=data.get("url"),
        text=data.get("text"),
    )


def chat_message(data: dict) -> "ChatMessage":
    from .types import ChatMessage
    if not data:
        return None
    
    return ChatMessage(
        id=data.get("id"),
        text=data.get("text"),
        created_at=data.get("createdAt"),
        deleted_at=data.get("deletedAt"),
        is_read=data.get("isRead"),
        is_suspicious=data.get("isSuspicious"),
        is_bulk_messaging=data.get("isBulkMessaging"),
        images=[file(img) for img in (data.get("images") or [])],
        game=game(data.get("game")),
        user=user_profile(data.get("user")),
        deal=item_deal(data.get("deal")),
        item=item(data.get("item")),
        transaction=transaction(data.get("transaction")),
        moderator=moderator(data.get("moderator")),
        event=ChatMessageEvents.__members__.get(data.get("event")),
        event_by_user=user_profile(data.get("eventByUser")),
        event_to_user=user_profile(data.get("eventToUser")),
        is_auto_response=data.get("isAutoResponse"),
        buttons=[chat_message_button(btn) for btn in (data.get("buttons") or [])],
    )


def chat_message_page_info(data: dict) -> "ChatMessagePageInfo":
    from .types import ChatMessagePageInfo
    if not data:
        return None

    return ChatMessagePageInfo(
        start_cursor=data.get("startCursor"),
        end_cursor=data.get("endCursor"),
        has_previous_page=data.get("hasPreviousPage"),
        has_next_page=data.get("hasNextPage"),
    )


def chat_message_list(data: dict) -> "ChatMessageList":
    from .types import ChatMessageList
    if not data:
        return None
    
    return ChatMessageList(
        messages=[chat_message(edge.get("node")) for edge in (data.get("edges") or [])],
        page_info=chat_message_page_info(data.get("pageInfo")),
        total_count=data.get("totalCount"),
    )


def message_template(data: dict) -> "MessageTemplate":
    from .types import MessageTemplate
    if not data:
        return None
    
    return MessageTemplate(
        id=data.get("id"),
        type=MessageTemplateTypes.__members__.get(data.get("type")),
        title=data.get("title"),
        text=data.get("text"),
        sequence=data.get("sequence"),
        created_at=data.get("createdAt"),
        group=data.get("group")
    )


def message_template_page_info(data: dict) -> "MessageTemplatePageInfo":
    from .types import MessageTemplatePageInfo
    if not data:
        return None

    return MessageTemplatePageInfo(
        start_cursor=data.get("startCursor"),
        end_cursor=data.get("endCursor"),
        has_previous_page=data.get("hasPreviousPage"),
        has_next_page=data.get("hasNextPage"),
    )


def message_template_list(data: dict) -> "MessageTemplateList":
    from .types import MessageTemplateList
    if not data:
        return None
    
    return MessageTemplateList(
        message_templates=[message_template(edge.get("node")) for edge in (data.get("edges") or [])],
        page_info=message_template_page_info(data.get("pageInfo")),
        total_count=data.get("totalCount"),
    )